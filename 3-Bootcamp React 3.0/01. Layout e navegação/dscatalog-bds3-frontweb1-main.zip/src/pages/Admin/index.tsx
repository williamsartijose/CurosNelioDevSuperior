const Admin = () => {
  return <h1>Página Admin</h1>;
};

export default Admin;
