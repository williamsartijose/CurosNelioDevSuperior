export type UserDTO = {
    id: number;
    name: string;
    email: string;
};